<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="css/fadestyle.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<title> Login Form </title>
</head>

<body>

  <div class="container">
  <form method="post">
    <div class="form-input">
      <input type="text" name="uname" value"" placeholder="Enter Username" required><br/>
      <input type="password" name="pass" value"" placeholder="Enter Password" required><br/>
            <input type="submit" name="submit" value"LOGIN"><br/>
            <a href ="#">Forget Password</a>
          </div>
        </form>
        </div
</body>
</html>
