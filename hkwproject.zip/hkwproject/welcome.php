<?php

 echo "You have just created a new profile";

?>
