<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Created 99-99-9999 by name -->
<!-- This page demonstrates functions -->
<title>Functions</title>
<meta http-equiv="Content-Type"
content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Using some predefined PHP functions</h1>
<hr />
<p>This is results of the round(3.556) function.</p>
<?php echo round(3.556); ?>

<p>This is results of the round(3.556,2) function.</p>
<?php echo round(3.556,2); ?>

<p>This is results of the date("m.d.y") function.</p>
<?php echo date("m.d.y") ; ?>

</body>
</html>
