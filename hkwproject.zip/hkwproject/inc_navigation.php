
<!--Learning Unit 3
Author: Heather Whittlesey
6/18/20 -->

<!DOCTYPE html>
<html>
<head>

</head>
  <body>
<p><br></p>


</body>


<div class="nav">
  <a href=http://localhost/hkwproject/index.php "#home">Home</a>
  <a href="#purchase">Purchase</a>
  <a class="active"<a href="#supplies">Supplies</a>
  <a href="#classes">Classes</a>
  <a href="#contact">Contact</a>
  <a href="#collections">Collections</a>
  <a href="#about">About</a>





</html>
