<?php

echo getenv('USERNAME');

var_dump($GLOBALS);


var_dump($_SERVER);


echo $_SERVER['SCRIPT_NAME'];

phpinfo();

?>
